"""Build the canonical information graph from parsed structure + SQL analysis.

Every node label and relationship produced here is defined in `schema.py`.
Run `schema.validate_graph(g)` after building to confirm conformance.

Two passes: (1) create object/unit nodes, their declared symbols, blocks,
statements, tables/views/columns, features; (2) resolve calls.
"""
from __future__ import annotations

import re
from typing import List, Dict, Tuple, Optional

from .plsql_structure import PlsqlObject, PlsqlUnit
from .sql_analyzer import analyze_statement
from .graph_model import Graph, nid

_CONTAINER_KINDS = {"PACKAGE", "PACKAGE BODY"}
_VIEW_HINT = re.compile(r"(?i)(^v_|^vw_|_v$|_vw$|_view$)")


def _is_view(name: str, catalog: Optional[dict]) -> bool:
    if catalog and name.lower() in {v.lower() for v in catalog.get("views", [])}:
        return True
    return bool(_VIEW_HINT.search(name))


def build_graph(objects: List[PlsqlObject], catalog: Optional[dict] = None,
                schema_name: Optional[str] = None, include_columns: bool = True) -> Graph:
    g = Graph()
    registry: Dict[str, str] = {}
    pending_calls: List[Tuple[str, List[str]]] = []

    schema_id = None
    if schema_name:
        schema_id = nid("schema", schema_name)
        g.add_node(schema_id, "Schema", name=schema_name)

    for obj in objects:
        if obj.kind in _CONTAINER_KINDS:
            obj_id = nid(obj.kind, obj.name)
            g.add_node(obj_id, "Package", name=obj.name, plsql_kind=obj.kind)
            if schema_id:
                g.add_edge(schema_id, "DEFINES", obj_id)
            for unit in obj.units:
                unit_id = nid(obj.name, unit.kind, unit.name)
                _add_unit_node(g, unit_id, unit, owner=obj.name,
                               catalog=catalog, include_columns=include_columns)
                g.add_edge(obj_id, "CONTAINS", unit_id)
                registry[unit.name.lower()] = unit_id
                pending_calls.append((unit_id, unit.calls))
        else:
            unit = obj.units[0]
            unit_id = nid(obj.kind, obj.name)
            label = "Function" if unit.kind == "FUNCTION" else "Procedure"
            _add_unit_node(g, unit_id, unit, owner="",
                           catalog=catalog, include_columns=include_columns)
            if schema_id:
                g.add_edge(schema_id, "DEFINES", unit_id)
            registry[obj.name.lower()] = unit_id
            pending_calls.append((unit_id, unit.calls))

    for caller_id, names in pending_calls:
        for name in names:
            target = registry.get(name.lower())
            if target is None:
                target = nid("external", name.lower())
                g.add_node(target, "External", name=name)
            g.add_edge(caller_id, "CALLS", target)

    return g


def _relation_node(g: Graph, name: str, catalog: Optional[dict]) -> Tuple[str, str]:
    label = "View" if _is_view(name, catalog) else "Table"
    rid = nid(label.lower(), name)
    g.add_node(rid, label, name=name)
    return rid, label


def _add_unit_node(g: Graph, unit_id: str, unit: PlsqlUnit, owner: str,
                   catalog: Optional[dict], include_columns: bool) -> None:
    label = "Function" if unit.kind == "FUNCTION" else "Procedure"
    g.add_node(unit_id, label, name=unit.name, owner=owner)

    # Body block (named after the routine) holds statements; cursors attach to it.
    block_id = nid(unit_id, "block")
    g.add_node(block_id, "Block", name=f"{unit.name}_body")
    g.add_edge(unit_id, "HAS_BLOCK", block_id)

    # Declared symbols: parameters, variables, constants, cursors.
    cursor_ids: Dict[str, str] = {}
    for sym in unit.symbols:
        sym_label = {"PARAMETER": "Parameter", "VARIABLE": "Variable",
                     "CONSTANT": "Constant", "CURSOR": "Cursor"}[sym.kind]
        sym_id = nid(unit_id, "sym", sym.kind, sym.name)
        g.add_node(sym_id, sym_label, name=sym.name,
                   datatype=sym.datatype, mode=sym.mode)
        g.add_edge(unit_id, "DECLARES", sym_id)
        if sym.kind == "CURSOR":
            cursor_ids[sym.name.lower()] = sym_id
            g.add_edge(unit_id, "USES_CURSOR", sym_id)

    # Procedural features.
    for feat, count in unit.features.items():
        feat_id = nid("feature", feat)
        g.add_node(feat_id, "Feature", name=feat)
        g.add_edge(unit_id, "HAS_FEATURE", feat_id, count=count)
        if "cursor_for_loop" in feat or feat == "while_loop" or feat == "basic_loop":
            loop_id = nid(unit_id, "loop", feat)
            g.add_node(loop_id, "Loop", name=feat)
            g.add_edge(block_id, "CONTAINS", loop_id)
        if feat == "exception_handler":
            eh_id = nid(unit_id, "exc")
            g.add_node(eh_id, "ExceptionHandler", name="WHEN OTHERS")
            g.add_edge(unit_id, "HANDLES", eh_id)
        if feat == "if_branch":
            br_id = nid(unit_id, "branch")
            g.add_node(br_id, "Branch", name="IF")
            g.add_edge(block_id, "CONTAINS", br_id)

    # Dynamic DDL targets (EXECUTE IMMEDIATE 'truncate table X').
    for tbl in unit.dynamic_writes:
        tid, _ = _relation_node(g, tbl, catalog)
        # Represent as a TRUNCATE statement so reads/writes stay on SqlStatement.
        st_id = nid(unit_id, "dynstmt", tbl)
        g.add_node(st_id, "SqlStatement", kind="TRUNCATE", dynamic=True,
                   text=f"EXECUTE IMMEDIATE 'truncate table {tbl}'")
        g.add_edge(block_id, "EXECUTES", st_id)
        g.add_edge(st_id, "WRITES", tid)

    # Static SQL statements.
    for idx, stmt in enumerate(unit.statements):
        a = analyze_statement(stmt.text)
        stmt_id = nid(unit_id, "stmt", str(idx))
        g.add_node(
            stmt_id, "SqlStatement",
            kind=a.kind, joins=a.joins, aggregates=a.aggregates,
            window_funcs=a.window_funcs, has_group_by=a.has_group_by,
            oracle_specific=",".join(a.oracle_specific), parse_ok=a.parse_ok,
            spark_sql=a.spark_sql or "", text=stmt.text[:500],
        )
        g.add_edge(block_id, "EXECUTES", stmt_id)
        for t in a.reads:
            rid, lbl = _relation_node(g, t, catalog)
            g.add_edge(stmt_id, "READS", rid)
            if lbl == "View":
                g.add_edge(stmt_id, "USES_VIEW", rid)
        for t in a.writes:
            tid, _ = _relation_node(g, t, catalog)
            g.add_edge(stmt_id, "WRITES", tid)
        if include_columns:
            for col in a.columns:
                cid = nid(stmt_id, "col", col)
                g.add_node(cid, "Column", name=col)
                g.add_edge(stmt_id, "REFERENCES", cid)
