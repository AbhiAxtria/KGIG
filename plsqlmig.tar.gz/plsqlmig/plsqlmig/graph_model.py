"""In-memory information graph: typed nodes and relationships."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Dict, List, Any


@dataclass
class Node:
    id: str
    label: str                      # Package | Procedure | Function | SqlStatement | Table ...
    props: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Edge:
    src: str
    rel: str                        # CONTAINS | EXECUTES | READS | WRITES | CALLS | HAS_FEATURE
    dst: str
    props: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Graph:
    nodes: Dict[str, Node] = field(default_factory=dict)
    edges: List[Edge] = field(default_factory=list)

    def add_node(self, id: str, label: str, **props) -> str:
        if id in self.nodes:
            self.nodes[id].props.update(props)
        else:
            self.nodes[id] = Node(id=id, label=label, props=props)
        return id

    def add_edge(self, src: str, rel: str, dst: str, **props) -> None:
        self.edges.append(Edge(src=src, rel=rel, dst=dst, props=props))

    def stats(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for n in self.nodes.values():
            out[n.label] = out.get(n.label, 0) + 1
        out["_edges"] = len(self.edges)
        return out


def nid(*parts: str) -> str:
    """Deterministic node id from parts."""
    return hashlib.md5("::".join(parts).encode()).hexdigest()[:16]
