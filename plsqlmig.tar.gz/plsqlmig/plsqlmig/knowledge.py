"""
Knowledge-graph layer.

Adds two things to the structural graph so the graph alone is sufficient to
(a) regenerate a PySpark equivalent and (b) justify the convert/keep verdict:

  1. A reusable Oracle -> Spark mapping knowledge base, materialized as
     (:OracleConstruct)-[:MAPS_TO]->(:SparkConstruct) nodes, with each routine's
     statements/features linked via (:...)-[:USES_CONSTRUCT]->(:OracleConstruct).

  2. A per-routine (:MigrationAssessment) node linked by [:ASSESSED_AS], holding
     the decision, scores, and the convertibility breakdown.

`graph_verdict` reads the verdict back out of the graph using only nodes/edges,
demonstrating the graph is self-contained.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

from .graph_model import Graph, nid
from .scorer import UnitScore

# convertibility: DIRECT (1:1), REWRITE (possible, semantics differ), UNSUPPORTED.
# key -> (spark_equivalent, convertibility, note)
ORACLE_TO_SPARK: Dict[str, Tuple[str, str, str]] = {
    "nvl":               ("coalesce()", "DIRECT", "null fallback"),
    "decode":            ("when().otherwise()", "REWRITE", "conditional expression"),
    "sysdate":           ("current_timestamp()", "DIRECT", "wall clock"),
    "sequence_nextval":  ("monotonically_increasing_id() / row_number()", "REWRITE",
                          "not gap-free or globally ordered like an Oracle sequence"),
    "sequence_ref":      ("monotonically_increasing_id() / row_number()", "REWRITE",
                          "surrogate keys differ from Oracle sequence semantics"),
    "autonomous_txn":    ("(none)", "UNSUPPORTED",
                          "Spark has no independent nested transaction"),
    "commit":            ("(drop — the write is the commit)", "REWRITE",
                          "no multi-statement transaction; a Spark write is atomic per job"),
    "rollback":          ("idempotent overwrite / job failure", "REWRITE",
                          "no transactional rollback; rely on job-level retry"),
    "savepoint":         ("(none)", "UNSUPPORTED", "no savepoints / partial rollback"),
    "cursor_for_loop":   ("DataFrame transformation", "REWRITE",
                          "replace row-by-row loop with set-based ops"),
    "explicit_cursor":   ("DataFrame / collect()", "REWRITE", "avoid cursors"),
    "while_loop":        ("DataFrame transformation", "REWRITE", "avoid driver loops"),
    "basic_loop":        ("DataFrame transformation", "REWRITE", "avoid driver loops"),
    "bulk_collect":      ("DataFrame collect / transform", "REWRITE", "bulk fetch"),
    "dbms_pkg_call":     ("print() / logging / catalog ops", "REWRITE",
                          "DBMS_* packages have no single Spark analog"),
    "utl_pkg_call":      ("external Python libraries", "REWRITE",
                          "UTL_* (file/http/smtp) needs host-side libs"),
    "connect_by":        ("recursive CTE / GraphFrames", "REWRITE",
                          "hierarchical query, non-trivial in Spark"),
    "execute_immediate": ("df.write.mode('overwrite') / spark.sql()", "REWRITE",
                          "dynamic DDL; truncate+reload maps to overwrite"),
    "raise_app_error":   ("raise Exception", "DIRECT", "error signalling"),
    "exception_handler": ("try / except", "DIRECT", "error handling"),
    "if_branch":         ("Python if / when()", "DIRECT", "branching"),
    "merge":             ("Delta/Iceberg MERGE or join+write", "REWRITE",
                          "needs a transactional table format"),
    "truncate":          ("df.write.mode('overwrite')", "REWRITE", "truncate+reload"),
    "oracle_func:rownum":("row_number() over window", "REWRITE", "ordering-dependent"),
    "oracle_func:rowid": ("monotonically_increasing_id()", "REWRITE", "row identity"),
    "oracle_func:sys_guid": ("uuid()", "DIRECT", "guid"),
}


def _kb_lookup(token: str):
    t = token.lower()
    if t in ORACLE_TO_SPARK:
        return t, ORACLE_TO_SPARK[t]
    if t.startswith("oracle_func:") and t in ORACLE_TO_SPARK:
        return t, ORACLE_TO_SPARK[t]
    return None, None


def enrich_knowledge_graph(g: Graph, scores: List[UnitScore]) -> None:
    """Attach KB mapping nodes, USES_CONSTRUCT edges, and assessment nodes."""
    by_name = {(s.owner, s.name): s for s in scores}

    # Materialize the full KB once (so MAPS_TO knowledge lives in the graph).
    for oracle, (spark, conv, note) in ORACLE_TO_SPARK.items():
        oid = nid("oracle_construct", oracle)
        sid = nid("spark_construct", spark)
        g.add_node(oid, "OracleConstruct", name=oracle, convertibility=conv, note=note)
        g.add_node(sid, "SparkConstruct", name=spark)
        g.add_edge(oid, "MAPS_TO", sid, convertibility=conv)

    # Link routines/statements to the constructs they use, and assess each routine.
    for node in list(g.nodes.values()):
        if node.label not in ("Procedure", "Function"):
            continue
        used: Dict[str, str] = {}     # token -> convertibility

        for e in list(g.edges):
            if e.src != node.id:
                continue
            if e.rel == "HAS_FEATURE":
                feat = g.nodes[e.dst].props.get("name", "")
                tok, hit = _kb_lookup(feat)
                if hit:
                    used[tok] = hit[1]
                    g.add_edge(node.id, "USES_CONSTRUCT", nid("oracle_construct", tok))
            elif e.rel == "HAS_BLOCK":
                blk = e.dst
                for e2 in g.edges:
                    if e2.src == blk and e2.rel == "EXECUTES":
                        sp = g.nodes[e2.dst].props
                        if sp.get("kind") == "MERGE":
                            used["merge"] = "REWRITE"
                            g.add_edge(e2.dst, "USES_CONSTRUCT", nid("oracle_construct", "merge"))
                        if sp.get("kind") == "TRUNCATE":
                            used["truncate"] = "REWRITE"
                            g.add_edge(e2.dst, "USES_CONSTRUCT", nid("oracle_construct", "truncate"))
                        for tok in [t for t in sp.get("oracle_specific", "").split(",") if t]:
                            k, hit = _kb_lookup(tok)
                            if hit:
                                used[k] = hit[1]
                                g.add_edge(e2.dst, "USES_CONSTRUCT", nid("oracle_construct", k))

        n_direct = sum(1 for v in used.values() if v == "DIRECT")
        n_rewrite = sum(1 for v in used.values() if v == "REWRITE")
        blocking = sorted(k for k, v in used.items() if v == "UNSUPPORTED")

        s = by_name.get((node.props.get("owner", ""), node.props.get("name", "")))
        logic = node.props.get("logic_pattern", "PROCEDURAL")
        set_based = s.set_based_score if s else 0.0
        lock = s.oracle_lock_score if s else 0.0
        calls = s.call_count if s else 0
        decision = _decide(logic, set_based, lock, blocking, calls)
        confidence = _confidence(decision, logic, blocking, n_rewrite)

        a_id = nid(node.id, "assessment")
        g.add_node(
            a_id, "MigrationAssessment",
            decision=decision, logic_pattern=logic,
            set_based=round(set_based, 1), oracle_lock=round(lock, 1), calls=calls,
            n_direct=n_direct, n_rewrite=n_rewrite, n_unsupported=len(blocking),
            blocking=",".join(blocking), confidence=confidence,
        )
        g.add_edge(node.id, "ASSESSED_AS", a_id)


def _decide(logic: str, set_based: float, lock: float,
            blocking: List[str], calls: int) -> str:
    # True blockers (autonomous transaction, savepoint) keep it in Oracle.
    if blocking:
        return "KEEP_IN_ORACLE"
    if logic == "SET_BASED_TRANSFORM":
        return "CONVERT_TO_PYSPARK"
    if logic == "ROW_BY_ROW_CURSOR":
        return "REWRITE_FOR_PYSPARK"      # convertible, but must be vectorized
    if logic == "ORCHESTRATION":
        return "ORCHESTRATION"            # becomes Spark driver / DAG
    if logic == "OLTP_BOOKKEEPING":
        return "KEEP_IN_ORACLE"           # single-row transactional bookkeeping
    # PROCEDURAL fallback: lean on the structural scores
    if set_based >= 2.0 and lock <= 3.0:
        return "CONVERT_TO_PYSPARK"
    return "KEEP_IN_ORACLE"


def _confidence(decision: str, logic: str, blocking: List[str], n_rewrite: int) -> str:
    if decision == "CONVERT_TO_PYSPARK" and not blocking and n_rewrite <= 1:
        return "HIGH"
    if decision == "KEEP_IN_ORACLE" and (blocking or logic == "OLTP_BOOKKEEPING"):
        return "HIGH"
    if decision == "REWRITE_FOR_PYSPARK":
        return "MEDIUM"
    return "MEDIUM"


def graph_verdict(g: Graph) -> List[Dict]:
    """Read the convert/keep verdict back out of the graph alone."""
    out = []
    for node in g.nodes.values():
        if node.label not in ("Procedure", "Function"):
            continue
        for e in g.edges:
            if e.src == node.id and e.rel == "ASSESSED_AS":
                a = g.nodes[e.dst].props
                out.append({
                    "routine": node.props.get("name"),
                    "owner": node.props.get("owner", ""),
                    "logic_pattern": a.get("logic_pattern"),
                    "decision": a.get("decision"),
                    "confidence": a.get("confidence"),
                    "direct": a.get("n_direct"),
                    "rewrite": a.get("n_rewrite"),
                    "unsupported": a.get("n_unsupported"),
                    "blocking": a.get("blocking"),
                })
    return out
