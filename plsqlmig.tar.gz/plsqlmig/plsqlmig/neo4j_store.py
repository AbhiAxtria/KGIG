"""
Neo4j ingestion.

Writes the information graph using MERGE so re-runs are idempotent. Use
dry_run=True to emit Cypher to a file/stdout without a live database (useful
for review or when Neo4j isn't reachable yet).

Suggested constraints (run once in the DB):
    CREATE CONSTRAINT IF NOT EXISTS FOR (n:Procedure) REQUIRE n.id IS UNIQUE;
    CREATE CONSTRAINT IF NOT EXISTS FOR (n:Table)     REQUIRE n.id IS UNIQUE;
"""
from __future__ import annotations

from typing import List, Optional

from .graph_model import Graph


def _props_to_cypher(props: dict) -> str:
    items = []
    for k, v in props.items():
        if isinstance(v, bool):
            items.append(f"{k}: {str(v).lower()}")
        elif isinstance(v, (int, float)):
            items.append(f"{k}: {v}")
        else:
            safe = str(v).replace("\\", "\\\\").replace("'", "\\'")
            items.append(f"{k}: '{safe}'")
    return ", ".join(items)


def graph_to_cypher(g: Graph) -> List[str]:
    from .schema import cypher_constraints
    stmts: List[str] = list(cypher_constraints())
    for n in g.nodes.values():
        props = {"id": n.id, **n.props}
        stmts.append(f"MERGE (n:{n.label} {{id: '{n.id}'}}) SET n += {{{_props_to_cypher(props)}}};")
    for e in g.edges:
        rel_props = f" {{{_props_to_cypher(e.props)}}}" if e.props else ""
        stmts.append(
            f"MATCH (a {{id: '{e.src}'}}), (b {{id: '{e.dst}'}}) "
            f"MERGE (a)-[r:{e.rel}{rel_props}]->(b);"
        )
    return stmts


def ingest(g: Graph, uri: str, user: str, password: str,
           dry_run: bool = False, out_path: Optional[str] = None) -> None:
    cypher = graph_to_cypher(g)

    if dry_run:
        text = "\n".join(cypher)
        if out_path:
            with open(out_path, "w") as f:
                f.write(text + "\n")
            print(f"[dry-run] wrote {len(cypher)} Cypher statements to {out_path}")
        else:
            print(text)
        return

    from neo4j import GraphDatabase
    driver = GraphDatabase.driver(uri, auth=(user, password))
    with driver.session() as session:
        for stmt in cypher:
            session.run(stmt)
    driver.close()
    print(f"Ingested {len(g.nodes)} nodes and {len(g.edges)} edges into Neo4j.")
