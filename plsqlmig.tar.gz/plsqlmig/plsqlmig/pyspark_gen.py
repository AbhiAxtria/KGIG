"""
PySpark generator.

For units the scorer marks CONVERT_TO_PYSPARK or REWRITE_FOR_PYSPARK, emit a
PySpark skeleton. Each SQL statement is transpiled to Spark SQL (by sqlglot in
the analyzer) and wrapped in spark.sql(...). Writes become saveAsTable/insertInto.

This produces a *starting point* a developer finishes -- not guaranteed runnable
output, especially where the scorer flagged a rewrite.
"""
from __future__ import annotations

from typing import List

from .graph_model import Graph
from .scorer import UnitScore


def generate_pyspark(g: Graph, scores: List[UnitScore]) -> str:
    by_name = {(s.owner, s.name): s for s in scores}
    out: List[str] = [
        "from pyspark.sql import SparkSession",
        "",
        "spark = SparkSession.builder.appName('plsql_migration').enableHiveSupport().getOrCreate()",
        "",
    ]

    for node in g.nodes.values():
        if node.label not in ("Procedure", "Function"):
            continue
        owner = node.props.get("owner", "")
        name = node.props.get("name", "")
        s = by_name.get((owner, name))
        if not s or s.decision in ("KEEP_IN_ORACLE", "ORCHESTRATION"):
            continue

        out.append(f"def {name.lower()}():")
        out.append(f"    # source: {owner}.{name}  | decision: {s.decision}")
        if s.decision == "REWRITE_FOR_PYSPARK":
            out.append("    # NOTE: row-by-row / procedural logic — vectorize before use:")
            for r in s.rationale:
                if r.startswith("-Oracle"):
                    out.append(f"    #   {r}")

        block_ids = {e.dst for e in g.edges if e.src == node.id and e.rel == "HAS_BLOCK"}
        stmt_edges = [e for e in g.edges if e.src in block_ids and e.rel == "EXECUTES"]
        emitted = False
        for e in stmt_edges:
                sp = g.nodes[e.dst].props
                spark_sql = sp.get("spark_sql", "")
                writes = [g.nodes[w.dst].props["name"]
                          for w in g.edges if w.src == e.dst and w.rel == "WRITES"]
                if spark_sql:
                    emitted = True
                    sql_one_line = " ".join(spark_sql.split())
                    if writes and sp.get("kind") in ("INSERT", "MERGE"):
                        out.append(f"    df = spark.sql('''{sql_one_line}''')")
                        out.append(f"    df.write.mode('append').saveAsTable('{writes[0]}')")
                    else:
                        out.append(f"    spark.sql('''{sql_one_line}''')")
        if not emitted:
            out.append("    pass  # no transpilable SQL extracted")
        out.append("")

    return "\n".join(out)
