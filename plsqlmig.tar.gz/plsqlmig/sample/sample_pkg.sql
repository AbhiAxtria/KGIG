CREATE OR REPLACE PACKAGE BODY sales_etl AS

  -- Set-based, batch transformation. Strong PySpark candidate.
  PROCEDURE load_daily_summary(p_run_date IN DATE) IS
  BEGIN
    INSERT INTO daily_sales_summary (sale_date, region_id, total_amount, order_count)
    SELECT o.sale_date,
           o.region_id,
           SUM(o.amount)        AS total_amount,
           COUNT(*)             AS order_count
    FROM   orders o
    JOIN   regions r ON r.region_id = o.region_id
    WHERE  o.sale_date = p_run_date
    GROUP  BY o.sale_date, o.region_id;

    MERGE INTO region_rollup tgt
    USING (SELECT region_id, SUM(total_amount) amt
           FROM daily_sales_summary GROUP BY region_id) src
    ON (tgt.region_id = src.region_id)
    WHEN MATCHED THEN UPDATE SET tgt.amt = src.amt
    WHEN NOT MATCHED THEN INSERT (region_id, amt) VALUES (src.region_id, src.amt);

    COMMIT;
  END load_daily_summary;

  -- Row-by-row cursor loop with sequence + autonomous txn. Keep in Oracle.
  PROCEDURE post_invoices IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    CURSOR c_unposted IS
      SELECT invoice_id, customer_id, amount FROM invoices WHERE status = 'NEW';
    v_id NUMBER;
  BEGIN
    FOR rec IN c_unposted LOOP
      v_id := invoice_seq.NEXTVAL;
      UPDATE invoices SET status = 'POSTED', posting_id = v_id
       WHERE invoice_id = rec.invoice_id;
      INSERT INTO ledger (entry_id, customer_id, amount)
        VALUES (v_id, rec.customer_id, rec.amount);
      IF rec.amount > 10000 THEN
        DBMS_OUTPUT.PUT_LINE('Large invoice ' || rec.invoice_id);
      END IF;
    END LOOP;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END post_invoices;

END sales_etl;
/
