CREATE OR REPLACE PACKAGE BODY claims_engine AS

  -- Set-based transform: strong PySpark candidate.
  PROCEDURE rebuild_summary IS
  BEGIN
    INSERT INTO claim_summary (claim_dt, product_id, total_paid, claim_count)
    SELECT c.claim_dt, c.product_id, SUM(c.paid_amt), COUNT(*)
    FROM   claims c
    JOIN   products p ON p.product_id = c.product_id
    WHERE  c.status = 'CLOSED'
    GROUP  BY c.claim_dt, c.product_id;
    COMMIT;
  END rebuild_summary;

  -- Row-by-row with a NESTED procedure defined inside it.
  PROCEDURE process_pending IS
    CURSOR c_pend IS SELECT claim_id, amount, customer_id FROM claims WHERE status = 'PENDING';
    v_fee NUMBER;

    -- nested procedure (procedure-inside-procedure)
    PROCEDURE apply_fee(p_claim IN NUMBER, p_amt IN NUMBER) IS
    BEGIN
      v_fee := p_amt * 0.02;
      UPDATE claims SET fee = v_fee WHERE claim_id = p_claim;
      IF p_amt > 50000 THEN
        INSERT INTO audit_log (claim_id, note) VALUES (p_claim, 'high value');
      END IF;
    END apply_fee;

  BEGIN
    FOR rec IN c_pend LOOP
      apply_fee(rec.claim_id, rec.amount);
      INSERT INTO ledger (claim_id, customer_id, amount)
        VALUES (rec.claim_id, rec.customer_id, rec.amount);
    END LOOP;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END process_pending;

  -- Orchestrator: calls the others.
  PROCEDURE run_all IS
  BEGIN
    rebuild_summary;
    process_pending;
  END run_all;

END claims_engine;
/
