CREATE OR REPLACE PROCEDURE extr_Customer IS
BEGIN
  INSERT INTO AR_CUSTOMER (cust_id, name, region_id)
  SELECT c.id, c.name, c.region_id FROM source_customers c WHERE c.active = 'Y';
  COMMIT;
END extr_Customer;

CREATE OR REPLACE PROCEDURE extr_Balance IS
BEGIN
  INSERT INTO AR_BALANCE (acct_id, bal, asof)
  SELECT b.acct_id, SUM(b.amount), SYSDATE
  FROM balances b GROUP BY b.acct_id;
  COMMIT;
END extr_Balance;
